const students=require('./studentdb') //import student data

//write function to get all the students
function getstudents(){
    return students;
}

//find particular student according to ID
function getStudent(id){
    return students.find((student)=>student.regno==id)
}

//Q1-student by gender
function getByGender(gen){
    return students.filter((student)=>student.gender==gen)
}

//




//export our all the available functions
module.exports={getStudent,getstudents,getByGender}

