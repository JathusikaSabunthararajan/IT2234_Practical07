
//array of student JSON details

let students = [
    {regno:'2021ICT10', name:'Harshan', age:'24', course:'IT', gender: 'Male'},
	{regno:'2021ICT41', name:'Nipunika', age:'25', course:'IT', gender: 'Female'},
	{regno:'2021ICT178', name:'Malani', age:'56', course:'BST', gender: 'Female'},
    {regno:'2021ICT12', name:'Jane', age:'24', course:'IT', gender: 'Female'},
	{regno:'2021ICT56', name:'Chathura', age:'25', course:'BST', gender: 'Male'},
	{regno:'2021ICT78', name:'Ananda', age:'56', course:'IT', gender: 'Male'}
];

module.exports = students; //array name